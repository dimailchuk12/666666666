
import SwiftUI

@main
struct CashAppCloneApp: App {
    var body: some Scene {
        WindowGroup {
            HomeView()
        }
    }
}
