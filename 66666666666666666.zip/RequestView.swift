
import SwiftUI

struct RequestView: View {
    var body: some View {
        Text("Request Screen")
            .navigationTitle("Request Money")
    }
}
